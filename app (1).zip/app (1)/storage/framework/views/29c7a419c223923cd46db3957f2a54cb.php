<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Welcome</title>
  <link rel='stylesheet' href='//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css'>
  <link rel="stylesheet" href="/style.css">

</head>

<body>

  <div class="login-card">
    <h1>Welcome</h1><br>
    <h3>Please make your choise</h3><br>
    <button onclick="location.href = 'login';" class="login login-button">Login</button>
    <button name="login" onclick="location.href = 'register';" class="login login-button">Register</button>
  </div>
  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src='//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>
</body>

</html><?php /**PATH /home/commilesome/public_html/dimitriou/orestis_demo/resources/views/welcome.blade.php ENDPATH**/ ?>